#!/bin/sh

libtoolize --force
automake --add-missing
autoreconf

